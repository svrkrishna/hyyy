# Box
A cron application which sends a pulse to a database regularly.

#### Environment Variables Required:
 - DB_USERNAME
 - DB_PASSWORD
 - DB_HOST
 - DB_PORT
 - DB_NAME
 - ENVIRONMENT

This project works together with [Data Visualization][1] project.

[1]:https://github.com/aye0aye/dv

Example Check Trigger 222

Example Check Trigger Hook

Example Check Trigger Hook Again

Hook for NodeJS Project.


Hook for NodeJS Project. Try Aagin

Validating JDK Error is resolved
