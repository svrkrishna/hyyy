module.exports = {
  color: '#038505'  //GREEN
  //color: '#1657b8'  //BLUE
  //color: '#980c8e'  //PURPLE
  //color: '#bf4912'  //RED
  //color: '#ac8601'  //ORANGE
  //color: '#449999'  //TEAL
  //color: '#FFFF00'  //YELLOW
};
